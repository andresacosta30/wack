export const fmtDate = d => d ? new Date(d + 'T00:00:00').toLocaleDateString('es-SV', { day: '2-digit', month: 'short', year: 'numeric' }) : '—'
export const fmtMoney = n => n ? `$${Number(n).toLocaleString()}` : '—'
export const todayStr = () => new Date().toISOString().split('T')[0]

export function Btn({ children, variant = 'p', sm, onClick, disabled, style }) {
  return (
    <button className={`btn btn-${variant}${sm ? ' btn-sm' : ''}`} onClick={onClick} disabled={disabled} style={style}>
      {children}
    </button>
  )
}

export function Bdg({ estado }) {
  return <span className={`bdg bdg-${estado}`}>{estado}</span>
}

export function Fi({ label, type = 'text', value, onChange, placeholder, options, as }) {
  return (
    <div className="fg">
      {label && <label className="fl">{label}</label>}
      {as === 'select' ? (
        <select className="fi" value={value} onChange={e => onChange(e.target.value)}>
          {options.map(o => <option key={o.value ?? o} value={o.value ?? o}>{o.label ?? o}</option>)}
        </select>
      ) : as === 'textarea' ? (
        <textarea className="fi" value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} />
      ) : (
        <input className="fi" type={type} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} />
      )}
    </div>
  )
}
