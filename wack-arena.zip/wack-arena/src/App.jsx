import { useState } from 'react'
import { supabase } from './lib/supabase'
import Dashboard from './views/Dashboard'
import AgendaView from './views/AgendaView'
import EquipoView from './views/EquipoView'
import ServiciosView from './views/ServiciosView'
import TorneosView from './views/TorneosView'
import './styles/app.css'

export default function App() {
  const [view, setView] = useState('dashboard')
  const [torneoView, setTorneoView] = useState('list')
  const [selTorneo, setSelTorneo] = useState(null)
  const [torneoTab, setTorneoTab] = useState('fixture')

  const nav = [
    ['dashboard', '🏠 Dashboard'],
    ['agenda',    '📅 Agenda'],
    ['equipo',    '👥 Equipo'],
    ['servicios', '🎯 Servicios'],
    ['torneos',   '🎮 Torneos'],
  ]

  return (
    <div className="app">
      <header className="hdr">
        <div className="logo">WACK <em>ARENA</em></div>
        <nav className="nav">
          {nav.map(([v, l]) => (
            <button
              key={v}
              className={`nb ${view === v ? 'on' : ''}`}
              onClick={() => { setView(v); if (v === 'torneos') setTorneoView('list') }}
            >{l}</button>
          ))}
        </nav>
      </header>

      <div className="pg">
        {view === 'dashboard' && <Dashboard supabase={supabase} setView={setView} />}
        {view === 'agenda'    && <AgendaView supabase={supabase} />}
        {view === 'equipo'    && <EquipoView supabase={supabase} />}
        {view === 'servicios' && <ServiciosView supabase={supabase} />}
        {view === 'torneos'   && (
          <TorneosView
            supabase={supabase}
            torneoView={torneoView}
            setTorneoView={setTorneoView}
            selTorneo={selTorneo}
            setSelTorneo={setSelTorneo}
            torneoTab={torneoTab}
            setTorneoTab={setTorneoTab}
          />
        )}
      </div>
    </div>
  )
}
