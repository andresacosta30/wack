import { useState, useEffect } from 'react'
import { Btn, Bdg, Fi } from '../components/ui'

function rrGen(teams) {
  if (teams.length < 2) return []
  const t = [...teams]
  if (t.length % 2) t.push(null)
  const n = t.length, rounds = []
  for (let r = 0; r < n - 1; r++) {
    const m = []
    for (let i = 0; i < n / 2; i++)
      if (t[i] && t[n-1-i]) m.push({ e1: t[i], e2: t[n-1-i] })
    if (m.length) rounds.push(m)
    t.splice(1, 0, t.pop())
  }
  return rounds
}

export default function TorneosView({ supabase, torneoView, setTorneoView, selTorneo, setSelTorneo, torneoTab, setTorneoTab }) {
  if (torneoView === 'list')   return <ListaTorneos supabase={supabase} onNew={() => setTorneoView('crear')} onSelect={t => { setSelTorneo(t); setTorneoTab('fixture'); setTorneoView('detail') }} />
  if (torneoView === 'crear')  return <CrearTorneo supabase={supabase} onBack={() => setTorneoView('list')} onCreated={() => setTorneoView('list')} />
  if (torneoView === 'detail') return <TorneoDetail supabase={supabase} torneo={selTorneo} onBack={() => setTorneoView('list')} onUpdate={setSelTorneo} tab={torneoTab} setTab={setTorneoTab} />
  return null
}

function ListaTorneos({ supabase, onNew, onSelect }) {
  const [torneos, setTorneos] = useState([])
  const [loading, setLoading] = useState(true)

  async function load() {
    const { data } = await supabase.from('torneos').select('*').order('created_at', { ascending: false })
    setTorneos(data || [])
    setLoading(false)
  }

  useEffect(() => { load() }, [])

  return (
    <div>
      <div className="row-b">
        <h1 className="ptitle">Torneos</h1>
        <div className="row">
          <Btn variant="s" sm onClick={load}>↺</Btn>
          <Btn onClick={onNew}>+ Nuevo</Btn>
        </div>
      </div>
      {loading && <p className="muted">Cargando...</p>}
      {!loading && torneos.length === 0 && (
        <div className="empty"><div style={{ fontSize: 32, marginBottom: 8 }}>🎮</div><p>No hay torneos aún.</p></div>
      )}
      {torneos.map(t => (
        <div key={t.id} className="card click" onClick={() => onSelect(t)}>
          <div className="row-b">
            <div>
              <Bdg estado={t.estado} />
              <div style={{ fontWeight: 700, fontSize: 16, margin: '4px 0 6px' }}>{t.nombre}</div>
              <div className="row">
                {t.juego && <span className="tag">{t.juego}</span>}
                <span className="muted">{t.formato === 'round_robin' ? 'Round Robin' : 'Eliminación'} · {t.max_por_equipo}v{t.max_por_equipo}</span>
              </div>
            </div>
            <span style={{ color: '#64748b', fontSize: 20 }}>›</span>
          </div>
        </div>
      ))}
    </div>
  )
}

function CrearTorneo({ supabase, onBack, onCreated }) {
  const [step, setStep] = useState(1)
  const [form, setForm] = useState({ nombre: '', juego: '', formato: 'round_robin', max_por_equipo: 1 })
  const [jugadores, setJugadores] = useState([])
  const [nj, setNj] = useState({ nombre: '', alias: '' })
  const [err, setErr] = useState('')
  const [loading, setLoading] = useState(false)

  function addJ() {
    if (!nj.nombre.trim()) return
    setJugadores(p => [...p, { ...nj, _id: Date.now() + Math.random() }])
    setNj({ nombre: '', alias: '' })
  }

  async function crear() {
    if (jugadores.length < 2) { setErr('Mínimo 2 participantes'); return }
    setLoading(true)
    const { data: t } = await supabase.from('torneos').insert({ ...form, estado: 'activo' }).select().single()
    const eqs = []
    for (const j of jugadores) {
      const { data: eq } = await supabase.from('g_equipos').insert({ torneo_id: t.id, nombre: j.nombre }).select().single()
      await supabase.from('g_jugadores').insert({ equipo_id: eq.id, nombre: j.nombre, alias: j.alias || null })
      eqs.push(eq)
    }
    if (form.formato === 'round_robin') {
      const rounds = rrGen(eqs)
      const parts = []
      rounds.forEach((r, ri) => r.forEach(m => parts.push({ torneo_id: t.id, equipo1_id: m.e1.id, equipo2_id: m.e2.id, ronda: ri + 1, estado: 'pendiente' })))
      if (parts.length) await supabase.from('partidas').insert(parts)
    }
    setLoading(false)
    onCreated()
  }

  return (
    <div>
      <button className="back" onClick={onBack}>← Volver</button>
      <h1 className="ptitle">Nuevo Torneo</h1>
      {err && <div className="alert alert-err">{err}</div>}

      {step === 1 && (
        <div className="card">
          <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 1.5, textTransform: 'uppercase', color: '#475569', marginBottom: 14 }}>Paso 1 — Info</div>
          <Fi label="Nombre *" value={form.nombre} onChange={v => setForm(p => ({ ...p, nombre: v }))} placeholder="Liga Smash Junio" />
          <Fi label="Juego" value={form.juego} onChange={v => setForm(p => ({ ...p, juego: v }))} placeholder="FC26, Smash Bros, Mario Kart..." />
          <div className="g2">
            <Fi label="Formato" as="select" value={form.formato} onChange={v => setForm(p => ({ ...p, formato: v }))}
              options={[{ value: 'round_robin', label: 'Round Robin' }, { value: 'eliminacion', label: 'Eliminación' }]} />
            <Fi label="Jugadores/equipo" as="select" value={form.max_por_equipo} onChange={v => setForm(p => ({ ...p, max_por_equipo: +v }))}
              options={[1,2,3,4,5].map(n => ({ value: n, label: `${n}v${n}` }))} />
          </div>
          <Btn onClick={() => { if (!form.nombre.trim()) { setErr('Ingresá el nombre'); return } setErr(''); setStep(2) }}>
            Siguiente →
          </Btn>
        </div>
      )}

      {step === 2 && (
        <div>
          <div className="card">
            <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 1.5, textTransform: 'uppercase', color: '#475569', marginBottom: 14 }}>Paso 2 — Participantes</div>
            <div className="g2" style={{ marginBottom: 10 }}>
              <div className="fg" style={{ marginBottom: 0 }}>
                <label className="fl">Nombre</label>
                <input className="fi" placeholder="Jugador / Equipo" value={nj.nombre} onChange={e => setNj(p => ({ ...p, nombre: e.target.value }))} onKeyDown={e => e.key === 'Enter' && addJ()} />
              </div>
              <div className="fg" style={{ marginBottom: 0 }}>
                <label className="fl">Alias</label>
                <input className="fi" placeholder="@alias" value={nj.alias} onChange={e => setNj(p => ({ ...p, alias: e.target.value }))} onKeyDown={e => e.key === 'Enter' && addJ()} />
              </div>
            </div>
            <Btn variant="s" sm onClick={addJ} style={{ marginBottom: 14 }}>+ Agregar</Btn>
            <div>
              {jugadores.length === 0 && <span className="muted sm">Mínimo 2 participantes.</span>}
              {jugadores.map(j => (
                <span key={j._id} className="pc">
                  {j.nombre}
                  {j.alias && <span className="muted"> @{j.alias}</span>}
                  <button className="pc-x" onClick={() => setJugadores(p => p.filter(x => x._id !== j._id))}>×</button>
                </span>
              ))}
            </div>
          </div>
          {jugadores.length >= 2 && (
            <div className="alert alert-info">
              {jugadores.length} participantes · {Math.floor(jugadores.length * (jugadores.length - 1) / 2)} partidas
            </div>
          )}
          <div className="row">
            <Btn variant="s" onClick={() => setStep(1)}>← Atrás</Btn>
            <Btn onClick={crear} disabled={loading || jugadores.length < 2}>
              {loading ? 'Creando...' : '🎮 Crear torneo'}
            </Btn>
          </div>
        </div>
      )}
    </div>
  )
}

function TorneoDetail({ supabase, torneo, onBack, onUpdate, tab, setTab }) {
  const [equipos, setEquipos] = useState([])
  const [partidas, setPartidas] = useState([])
  const [scores, setScores] = useState({})
  const [loading, setLoading] = useState(true)
  const [msg, setMsg] = useState('')

  async function load() {
    const [{ data: eqs }, { data: parts }] = await Promise.all([
      supabase.from('g_equipos').select('*').eq('torneo_id', torneo.id).order('created_at'),
      supabase.from('partidas').select('*, e1:equipo1_id(nombre), e2:equipo2_id(nombre)').eq('torneo_id', torneo.id).order('ronda')
    ])
    setEquipos(eqs || [])
    setPartidas(parts || [])
    const sc = {}
    ;(parts || []).forEach(p => { sc[p.id] = { s1: p.score1 ?? '', s2: p.score2 ?? '' } })
    setScores(sc)
    setLoading(false)
  }

  useEffect(() => { load() }, [torneo.id])

  async function guardar(p) {
    const sc = scores[p.id]
    if (sc.s1 === '' || sc.s2 === '') return
    await supabase.from('partidas').update({ score1: +sc.s1, score2: +sc.s2, estado: 'jugada' }).eq('id', p.id)
    setMsg('✓ Resultado guardado')
    setTimeout(() => setMsg(''), 2000)
    load()
  }

  async function finalizar() {
    await supabase.from('torneos').update({ estado: 'finalizado' }).eq('id', torneo.id)
    onUpdate({ ...torneo, estado: 'finalizado' })
  }

  function calcPos() {
    const st = {}
    equipos.forEach(e => { st[e.id] = { nombre: e.nombre, pts: 0, g: 0, em: 0, p: 0, gf: 0, gc: 0, j: 0 } })
    partidas.filter(p => p.estado === 'jugada').forEach(p => {
      if (!st[p.equipo1_id] || !st[p.equipo2_id]) return
      const [s1, s2] = [p.score1, p.score2]
      st[p.equipo1_id].j++; st[p.equipo2_id].j++
      st[p.equipo1_id].gf += s1; st[p.equipo1_id].gc += s2
      st[p.equipo2_id].gf += s2; st[p.equipo2_id].gc += s1
      if (s1 > s2)      { st[p.equipo1_id].pts += 3; st[p.equipo1_id].g++; st[p.equipo2_id].p++ }
      else if (s2 > s1) { st[p.equipo2_id].pts += 3; st[p.equipo2_id].g++; st[p.equipo1_id].p++ }
      else              { st[p.equipo1_id].pts++; st[p.equipo1_id].em++; st[p.equipo2_id].pts++; st[p.equipo2_id].em++ }
    })
    return Object.values(st).sort((a, b) => b.pts - a.pts || (b.gf - b.gc) - (a.gf - a.gc))
  }

  const pos = calcPos()
  const rondas = [...new Set(partidas.map(p => p.ronda))].sort((a, b) => a - b)
  const jugadas = partidas.filter(p => p.estado === 'jugada').length
  const posC = ['#f59e0b', '#94a3b8', '#b45309']

  return (
    <div>
      <button className="back" onClick={onBack}>← Volver</button>
      <div className="row-b">
        <div>
          <Bdg estado={torneo.estado} />
          <h1 className="ptitle" style={{ margin: '4px 0 6px' }}>{torneo.nombre}</h1>
          <div className="row">
            {torneo.juego && <span className="tag">{torneo.juego}</span>}
            <span className="muted">{equipos.length} participantes · {jugadas}/{partidas.length} partidas</span>
          </div>
        </div>
        {torneo.estado === 'activo' && jugadas === partidas.length && partidas.length > 0 && (
          <Btn variant="ok" sm onClick={finalizar}>✓ Finalizar</Btn>
        )}
      </div>

      {msg && <div className="alert alert-ok">{msg}</div>}

      <div className="tabs">
        {[['fixture','Fixture'],['posiciones','Posiciones'],['resultados','Resultados']].map(([k, l]) => (
          <button key={k} className={`tb ${tab === k ? 'on' : ''}`} onClick={() => setTab(k)}>{l}</button>
        ))}
      </div>

      {loading && <p className="muted">Cargando...</p>}

      {!loading && tab === 'fixture' && rondas.map(r => (
        <div key={r}>
          <div className="rh">Ronda {r}</div>
          {partidas.filter(p => p.ronda === r).map(p => (
            <div key={p.id} className="mc">
              <div style={{ flex: 1, fontWeight: 600, fontSize: 14, color: p.estado === 'jugada' && p.score1 > p.score2 ? '#10b981' : '#e2e8f0' }}>{p.e1?.nombre}</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 18, fontWeight: 700 }}>
                <span style={{ color: p.estado === 'jugada' ? '#e2e8f0' : '#64748b' }}>{p.score1 ?? '–'}</span>
                <span style={{ color: '#64748b', fontSize: 11 }}>vs</span>
                <span style={{ color: p.estado === 'jugada' ? '#e2e8f0' : '#64748b' }}>{p.score2 ?? '–'}</span>
              </div>
              <div style={{ flex: 1, fontWeight: 600, fontSize: 14, textAlign: 'right', color: p.estado === 'jugada' && p.score2 > p.score1 ? '#10b981' : '#e2e8f0' }}>{p.e2?.nombre}</div>
              <Bdg estado={p.estado} />
            </div>
          ))}
        </div>
      ))}

      {!loading && tab === 'posiciones' && (
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <table className="tbl">
            <thead>
              <tr>{['#','Participante','PTS','J','G','E','P','GF','GC','DIF'].map(h => <th key={h}>{h}</th>)}</tr>
            </thead>
            <tbody>
              {pos.map((p, i) => (
                <tr key={p.nombre}>
                  <td><span style={{ fontSize: 16, fontWeight: 700, color: posC[i] || '#64748b' }}>{i+1}</span></td>
                  <td style={{ fontWeight: 600 }}>{p.nombre}</td>
                  <td style={{ fontSize: 16, fontWeight: 800, color: '#06b6d4' }}>{p.pts}</td>
                  {[p.j, p.g, p.em, p.p, p.gf, p.gc].map((v, vi) => <td key={vi} className="muted">{v}</td>)}
                  <td style={{ color: p.gf - p.gc >= 0 ? '#10b981' : '#ef4444' }}>{p.gf - p.gc > 0 ? '+' : ''}{p.gf - p.gc}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {!loading && tab === 'resultados' && (
        <div>
          <p className="muted" style={{ marginBottom: 14 }}>Ingresá los scores y guardá.</p>
          {rondas.map(r => (
            <div key={r}>
              <div className="rh">Ronda {r}</div>
              {partidas.filter(p => p.ronda === r).map(p => (
                <div key={p.id} className="mc">
                  <div style={{ flex: 1, fontWeight: 600, minWidth: 70, fontSize: 14 }}>{p.e1?.nombre}</div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <input className="si" type="number" min="0" placeholder="0"
                      value={scores[p.id]?.s1 ?? ''}
                      onChange={e => setScores(prev => ({ ...prev, [p.id]: { ...prev[p.id], s1: e.target.value } }))} />
                    <span style={{ color: '#64748b', fontSize: 11 }}>vs</span>
                    <input className="si" type="number" min="0" placeholder="0"
                      value={scores[p.id]?.s2 ?? ''}
                      onChange={e => setScores(prev => ({ ...prev, [p.id]: { ...prev[p.id], s2: e.target.value } }))} />
                  </div>
                  <div style={{ flex: 1, fontWeight: 600, textAlign: 'right', minWidth: 70, fontSize: 14 }}>{p.e2?.nombre}</div>
                  <Btn variant={p.estado === 'jugada' ? 's' : 'ok'} sm onClick={() => guardar(p)}>
                    {p.estado === 'jugada' ? 'Actualizar' : 'Guardar'}
                  </Btn>
                </div>
              ))}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
