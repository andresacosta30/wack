import { useState, useEffect } from 'react'
import { Btn, Bdg, fmtDate, fmtMoney, todayStr } from '../components/ui'

export default function Dashboard({ supabase, setView }) {
  const [stats, setStats] = useState({ eventos: 0, torneos: 0, equipo: 0, ingresos: 0 })
  const [proximos, setProximos] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function load() {
      const mes = new Date().toISOString().slice(0, 7)
      const [{ data: prox }, { data: torn }, { data: eq }, { data: evMes }] = await Promise.all([
        supabase.from('eventos').select('*').gte('fecha', todayStr()).order('fecha').limit(5),
        supabase.from('torneos').select('id').eq('estado', 'activo'),
        supabase.from('equipo').select('id').eq('activo', true),
        supabase.from('eventos').select('precio').gte('fecha', mes + '-01').neq('estado', 'cancelado')
      ])
      const ingresos = (evMes || []).reduce((a, e) => a + (e.precio || 0), 0)
      setProximos(prox || [])
      setStats({ eventos: (prox || []).length, torneos: (torn || []).length, equipo: (eq || []).length, ingresos })
      setLoading(false)
    }
    load()
  }, [])

  return (
    <div>
      <div className="row-b"><h1 className="ptitle">Dashboard</h1></div>
      <div className="g4" style={{ marginBottom: 20 }}>
        {[
          ['📅', 'Próximos eventos', stats.eventos],
          ['🎮', 'Torneos activos', stats.torneos],
          ['👥', 'Equipo', stats.equipo],
          ['💰', 'Ingresos est. mes', `$${stats.ingresos.toLocaleString()}`],
        ].map(([icon, lbl, val]) => (
          <div key={lbl} className="stat-card">
            <div style={{ fontSize: 22, marginBottom: 4 }}>{icon}</div>
            <div className="stat-val">{val}</div>
            <div className="stat-lbl">{lbl}</div>
          </div>
        ))}
      </div>

      <div className="row-b">
        <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1, textTransform: 'uppercase', color: '#64748b' }}>Próximos eventos</span>
        <Btn variant="s" sm onClick={() => setView('agenda')}>Ver todos →</Btn>
      </div>

      {loading && <p className="muted">Cargando...</p>}
      {!loading && proximos.length === 0 && (
        <div className="empty"><div style={{ fontSize: 32, marginBottom: 8 }}>📅</div><p>No hay eventos próximos.</p></div>
      )}
      {proximos.map(e => (
        <div key={e.id} className={`ev-card ${e.estado}`}>
          <div className="row-b">
            <div>
              <div style={{ fontWeight: 600, marginBottom: 5 }}>{e.nombre}</div>
              <div className="row">
                {e.fecha && <span className="muted">📅 {fmtDate(e.fecha)}</span>}
                {e.hora_inicio && <span className="muted">🕐 {e.hora_inicio}{e.hora_fin ? ` – ${e.hora_fin}` : ''}</span>}
                {e.cliente && <span className="tag">{e.cliente}</span>}
                {e.precio && <span style={{ color: '#10b981', fontSize: 13, fontWeight: 600 }}>{fmtMoney(e.precio)}</span>}
              </div>
            </div>
            <Bdg estado={e.estado} />
          </div>
        </div>
      ))}
    </div>
  )
}
