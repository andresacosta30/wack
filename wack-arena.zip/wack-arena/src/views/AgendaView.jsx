import { useState, useEffect } from 'react'
import { Btn, Bdg, Fi, fmtDate, fmtMoney, todayStr } from '../components/ui'

export default function AgendaView({ supabase }) {
  const [eventos, setEventos] = useState([])
  const [equipo, setEquipo] = useState([])
  const [servicios, setServicios] = useState([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('todos')
  const [showForm, setShowForm] = useState(false)
  const [editing, setEditing] = useState(null)
  const [msg, setMsg] = useState('')

  async function load() {
    const [{ data: evs }, { data: eq }, { data: svcs }] = await Promise.all([
      supabase.from('eventos').select('*, evento_staff(staff_id, equipo(nombre))').order('fecha'),
      supabase.from('equipo').select('*').eq('activo', true).order('nombre'),
      supabase.from('servicios').select('*').eq('activo', true).order('nombre')
    ])
    setEventos(evs || [])
    setEquipo(eq || [])
    setServicios(svcs || [])
    setLoading(false)
  }

  useEffect(() => { load() }, [])

  async function guardar(form, staffIds) {
    const { nombre, cliente, servicio_id, fecha, hora_inicio, hora_fin, lugar, precio, estado, notas } = form
    const payload = { nombre, cliente, servicio_id: servicio_id || null, fecha: fecha || null, hora_inicio: hora_inicio || null, hora_fin: hora_fin || null, lugar, precio: precio ? +precio : null, estado, notas }
    let evId = editing?.id
    if (editing) {
      await supabase.from('eventos').update(payload).eq('id', editing.id)
      await supabase.from('evento_staff').delete().eq('evento_id', editing.id)
    } else {
      const { data: ev } = await supabase.from('eventos').insert(payload).select().single()
      evId = ev.id
    }
    if (staffIds.length) await supabase.from('evento_staff').insert(staffIds.map(sid => ({ evento_id: evId, staff_id: sid })))
    setShowForm(false); setEditing(null)
    setMsg(editing ? '✓ Evento actualizado' : '✓ Evento creado')
    setTimeout(() => setMsg(''), 2500)
    load()
  }

  async function cambiarEstado(ev, estado) {
    await supabase.from('eventos').update({ estado }).eq('id', ev.id)
    load()
  }

  async function eliminar(id) {
    if (!confirm('¿Eliminar este evento?')) return
    await supabase.from('eventos').delete().eq('id', id)
    load()
  }

  const filtered = filter === 'todos' ? eventos : eventos.filter(e => e.estado === filter)

  return (
    <div>
      <div className="row-b">
        <h1 className="ptitle">Agenda</h1>
        <Btn onClick={() => { setEditing(null); setShowForm(true) }}>+ Nuevo evento</Btn>
      </div>
      {msg && <div className="alert alert-ok">{msg}</div>}
      <div className="tabs">
        {['todos','pendiente','confirmado','completado','cancelado'].map(f => (
          <button key={f} className={`tb ${filter === f ? 'on' : ''}`} onClick={() => setFilter(f)}>{f}</button>
        ))}
      </div>
      {loading && <p className="muted">Cargando...</p>}
      {!loading && filtered.length === 0 && <div className="empty"><div style={{ fontSize: 32, marginBottom: 8 }}>📅</div><p>No hay eventos.</p></div>}
      {filtered.map(ev => (
        <div key={ev.id} className={`ev-card ${ev.estado}`}>
          <div className="row-b" style={{ marginBottom: 8 }}>
            <div style={{ flex: 1 }}>
              <div className="row" style={{ marginBottom: 5 }}>
                <span style={{ fontWeight: 700, fontSize: 15 }}>{ev.nombre}</span>
                <Bdg estado={ev.estado} />
              </div>
              <div className="row" style={{ marginBottom: ev.lugar ? 4 : 0 }}>
                {ev.fecha && <span className="muted">📅 {fmtDate(ev.fecha)}</span>}
                {ev.hora_inicio && <span className="muted">🕐 {ev.hora_inicio}{ev.hora_fin ? ` – ${ev.hora_fin}` : ''}</span>}
                {ev.cliente && <span className="tag">{ev.cliente}</span>}
                {ev.precio && <span style={{ color: '#10b981', fontWeight: 600, fontSize: 13 }}>{fmtMoney(ev.precio)}</span>}
              </div>
              {ev.lugar && <div className="muted" style={{ marginBottom: 4 }}>📍 {ev.lugar}</div>}
              {ev.evento_staff?.length > 0 && (
                <div className="row" style={{ marginTop: 5 }}>
                  <span className="muted sm">Staff:</span>
                  {ev.evento_staff.map(es => <span key={es.staff_id} className="pc">{es.equipo?.nombre}</span>)}
                </div>
              )}
            </div>
          </div>
          <div className="hr" />
          <div className="row">
            <Btn variant="s" sm onClick={() => { setEditing(ev); setShowForm(true) }}>✏ Editar</Btn>
            {ev.estado === 'pendiente'  && <Btn variant="ok" sm onClick={() => cambiarEstado(ev, 'confirmado')}>✓ Confirmar</Btn>}
            {ev.estado === 'confirmado' && <Btn variant="ok" sm onClick={() => cambiarEstado(ev, 'completado')}>✓ Completado</Btn>}
            {!['cancelado','completado'].includes(ev.estado) && <Btn variant="w" sm onClick={() => cambiarEstado(ev, 'cancelado')}>Cancelar</Btn>}
            <Btn variant="d" sm onClick={() => eliminar(ev.id)}>Eliminar</Btn>
          </div>
        </div>
      ))}
      {showForm && <EventoModal equipo={equipo} servicios={servicios} editing={editing} onGuardar={guardar} onClose={() => { setShowForm(false); setEditing(null) }} />}
    </div>
  )
}

function EventoModal({ equipo, servicios, editing, onGuardar, onClose }) {
  const [form, setForm] = useState({
    nombre: editing?.nombre || '', cliente: editing?.cliente || '',
    servicio_id: editing?.servicio_id || '', fecha: editing?.fecha || todayStr(),
    hora_inicio: editing?.hora_inicio || '', hora_fin: editing?.hora_fin || '',
    lugar: editing?.lugar || '', precio: editing?.precio || '',
    estado: editing?.estado || 'pendiente', notas: editing?.notas || ''
  })
  const [staffIds, setStaffIds] = useState(editing?.evento_staff?.map(es => es.staff_id) || [])
  const [saving, setSaving] = useState(false)
  const set = k => v => setForm(p => ({ ...p, [k]: v }))
  const toggleStaff = id => setStaffIds(p => p.includes(id) ? p.filter(x => x !== id) : [...p, id])

  return (
    <div className="modal-bg" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div className="modal-title">{editing ? 'Editar evento' : 'Nuevo evento'}</div>
        <Fi label="Nombre *" value={form.nombre} onChange={set('nombre')} placeholder="Activación LG Metrocentro" />
        <div className="g2">
          <Fi label="Cliente" value={form.cliente} onChange={set('cliente')} placeholder="Nombre de la marca" />
          <Fi label="Estado" as="select" value={form.estado} onChange={set('estado')} options={['pendiente','confirmado','completado','cancelado'].map(v => ({ value: v, label: v }))} />
        </div>
        <Fi label="Servicio" as="select" value={form.servicio_id} onChange={set('servicio_id')}
          options={[{ value: '', label: '— Sin asignar —' }, ...servicios.map(s => ({ value: s.id, label: s.nombre }))]} />
        <div className="g2">
          <Fi label="Fecha" type="date" value={form.fecha} onChange={set('fecha')} />
          <Fi label="Precio ($)" type="number" value={form.precio} onChange={set('precio')} placeholder="500" />
        </div>
        <div className="g2">
          <Fi label="Hora inicio" type="time" value={form.hora_inicio} onChange={set('hora_inicio')} />
          <Fi label="Hora fin" type="time" value={form.hora_fin} onChange={set('hora_fin')} />
        </div>
        <Fi label="Lugar" value={form.lugar} onChange={set('lugar')} placeholder="LG Store Metrocentro" />
        <div className="fg">
          <label className="fl">Staff asignado</label>
          <div style={{ display: 'flex', flexWrap: 'wrap', marginTop: 4 }}>
            {equipo.length === 0 && <span className="muted sm">Agregá miembros en Equipo primero.</span>}
            {equipo.map(e => (
              <div key={e.id} className={`cb-item ${staffIds.includes(e.id) ? 'on' : ''}`} onClick={() => toggleStaff(e.id)}>
                {staffIds.includes(e.id) ? '✓' : '+'} {e.nombre}
                {e.rol && <span className="muted"> · {e.rol}</span>}
              </div>
            ))}
          </div>
        </div>
        <Fi label="Notas" as="textarea" value={form.notas} onChange={set('notas')} placeholder="Instrucciones, requerimientos..." />
        <div className="row">
          <Btn disabled={saving || !form.nombre.trim()} onClick={async () => { setSaving(true); await onGuardar(form, staffIds); setSaving(false) }}>
            {saving ? 'Guardando...' : editing ? 'Actualizar' : 'Crear evento'}
          </Btn>
          <Btn variant="s" onClick={onClose}>Cancelar</Btn>
        </div>
      </div>
    </div>
  )
}
