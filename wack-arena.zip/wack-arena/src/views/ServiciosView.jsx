import { useState, useEffect } from 'react'
import { Btn, Fi } from '../components/ui'

const CAT_COLORS = { activacion: '#3b82f6', patrocinio: '#7c3aed', digital: '#10b981', otro: '#64748b' }

export default function ServiciosView({ supabase }) {
  const [servicios, setServicios] = useState([])
  const [loading, setLoading] = useState(true)
  const [catFilter, setCatFilter] = useState('todos')
  const [showForm, setShowForm] = useState(false)
  const [editing, setEditing] = useState(null)
  const [msg, setMsg] = useState('')

  async function load() {
    const { data } = await supabase.from('servicios').select('*').order('categoria').order('nombre')
    setServicios(data || [])
    setLoading(false)
  }

  useEffect(() => { load() }, [])

  async function guardar(form) {
    const payload = { ...form, precio: form.precio ? +form.precio : null }
    editing
      ? await supabase.from('servicios').update(payload).eq('id', editing.id)
      : await supabase.from('servicios').insert(payload)
    setShowForm(false); setEditing(null)
    setMsg(editing ? '✓ Servicio actualizado' : '✓ Servicio agregado')
    setTimeout(() => setMsg(''), 2500)
    load()
  }

  async function eliminar(id) {
    if (!confirm('¿Eliminar este servicio?')) return
    await supabase.from('servicios').delete().eq('id', id)
    load()
  }

  const cats = ['todos', ...new Set(servicios.map(s => s.categoria).filter(Boolean))]
  const filtered = catFilter === 'todos' ? servicios : servicios.filter(s => s.categoria === catFilter)

  return (
    <div>
      <div className="row-b">
        <h1 className="ptitle">Servicios</h1>
        <Btn onClick={() => { setEditing(null); setShowForm(true) }}>+ Agregar</Btn>
      </div>
      {msg && <div className="alert alert-ok">{msg}</div>}
      <div className="tabs">
        {cats.map(c => (
          <button key={c} className={`tb ${catFilter === c ? 'on' : ''}`} onClick={() => setCatFilter(c)}>{c}</button>
        ))}
      </div>
      {loading && <p className="muted">Cargando...</p>}
      {!loading && filtered.length === 0 && (
        <div className="empty">
          <div style={{ fontSize: 32, marginBottom: 8 }}>🎯</div>
          <p>No hay servicios.<br />Agregá los servicios de Wack.</p>
        </div>
      )}
      {filtered.map(sv => {
        const cc = CAT_COLORS[sv.categoria] || '#64748b'
        return (
          <div key={sv.id} className="card" style={{ borderLeft: `3px solid ${cc}` }}>
            <div style={{ marginBottom: 8 }}>
              <div className="row" style={{ marginBottom: 5 }}>
                <span style={{ fontWeight: 700, fontSize: 15 }}>{sv.nombre}</span>
                {sv.categoria && (
                  <span style={{ fontSize: 10, padding: '2px 7px', borderRadius: 4, background: `${cc}22`, color: cc, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.5px' }}>
                    {sv.categoria}
                  </span>
                )}
              </div>
              {sv.descripcion && <div className="muted sm" style={{ marginBottom: 6 }}>{sv.descripcion}</div>}
              <div className="row">
                {sv.precio
                  ? <span style={{ color: '#10b981', fontWeight: 700 }}>${sv.precio} + IVA</span>
                  : <span className="muted sm">A cotizar</span>}
                {sv.unidad && <span className="muted sm">/ {sv.unidad}</span>}
              </div>
            </div>
            <div className="hr" />
            <div className="row">
              <Btn variant="s" sm onClick={() => { setEditing(sv); setShowForm(true) }}>✏ Editar</Btn>
              <Btn variant="d" sm onClick={() => eliminar(sv.id)}>Eliminar</Btn>
            </div>
          </div>
        )
      })}
      {showForm && (
        <ServicioModal editing={editing} onGuardar={guardar} onClose={() => { setShowForm(false); setEditing(null) }} />
      )}
    </div>
  )
}

function ServicioModal({ editing, onGuardar, onClose }) {
  const [form, setForm] = useState({
    nombre: editing?.nombre || '',
    descripcion: editing?.descripcion || '',
    precio: editing?.precio || '',
    unidad: editing?.unidad || '',
    categoria: editing?.categoria || 'activacion'
  })
  const [saving, setSaving] = useState(false)
  const set = k => v => setForm(p => ({ ...p, [k]: v }))

  return (
    <div className="modal-bg" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div className="modal-title">{editing ? 'Editar servicio' : 'Nuevo servicio'}</div>
        <Fi label="Nombre *" value={form.nombre} onChange={set('nombre')} placeholder="Experiencia VR" />
        <Fi label="Descripción" as="textarea" value={form.descripcion} onChange={set('descripcion')} placeholder="Descripción del servicio..." />
        <Fi label="Categoría" as="select" value={form.categoria} onChange={set('categoria')}
          options={['activacion','patrocinio','digital','otro'].map(v => ({ value: v, label: v }))} />
        <div className="g2">
          <Fi label="Precio ($ sin IVA, vacío = cotizar)" type="number" value={form.precio} onChange={set('precio')} placeholder="100" />
          <Fi label="Unidad" value={form.unidad} onChange={set('unidad')} placeholder="hora/estación, mes..." />
        </div>
        <div className="row">
          <Btn disabled={saving || !form.nombre.trim()} onClick={async () => { setSaving(true); await onGuardar(form); setSaving(false) }}>
            {saving ? 'Guardando...' : editing ? 'Actualizar' : 'Agregar'}
          </Btn>
          <Btn variant="s" onClick={onClose}>Cancelar</Btn>
        </div>
      </div>
    </div>
  )
}
