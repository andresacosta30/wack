import { useState, useEffect } from 'react'
import { Btn, Bdg, Fi } from '../components/ui'

export default function EquipoView({ supabase }) {
  const [equipo, setEquipo] = useState([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editing, setEditing] = useState(null)
  const [msg, setMsg] = useState('')

  async function load() {
    const { data } = await supabase.from('equipo').select('*').order('nombre')
    setEquipo(data || [])
    setLoading(false)
  }

  useEffect(() => { load() }, [])

  async function guardar(form) {
    editing
      ? await supabase.from('equipo').update(form).eq('id', editing.id)
      : await supabase.from('equipo').insert(form)
    setShowForm(false); setEditing(null)
    setMsg(editing ? '✓ Actualizado' : '✓ Miembro agregado')
    setTimeout(() => setMsg(''), 2500)
    load()
  }

  async function toggleActivo(m) {
    await supabase.from('equipo').update({ activo: !m.activo }).eq('id', m.id)
    load()
  }

  async function eliminar(id) {
    if (!confirm('¿Eliminar este miembro?')) return
    await supabase.from('equipo').delete().eq('id', id)
    load()
  }

  return (
    <div>
      <div className="row-b">
        <h1 className="ptitle">Equipo</h1>
        <Btn onClick={() => { setEditing(null); setShowForm(true) }}>+ Agregar</Btn>
      </div>
      {msg && <div className="alert alert-ok">{msg}</div>}
      {loading && <p className="muted">Cargando...</p>}
      {!loading && equipo.length === 0 && (
        <div className="empty"><div style={{ fontSize: 32, marginBottom: 8 }}>👥</div><p>No hay miembros aún.</p></div>
      )}
      {equipo.map(m => (
        <div key={m.id} className="card" style={{ opacity: m.activo ? 1 : .5 }}>
          <div style={{ marginBottom: 8 }}>
            <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 5 }}>{m.nombre}</div>
            <div className="row">
              {m.rol && <span className="tag">{m.rol}</span>}
              {m.alias && <span className="muted">@{m.alias}</span>}
              {m.contacto && <span className="muted">📱 {m.contacto}</span>}
              <Bdg estado={m.activo ? 'activo' : 'finalizado'} />
            </div>
            {m.notas && <div className="muted sm" style={{ marginTop: 6 }}>{m.notas}</div>}
          </div>
          <div className="hr" />
          <div className="row">
            <Btn variant="s" sm onClick={() => { setEditing(m); setShowForm(true) }}>✏ Editar</Btn>
            <Btn variant={m.activo ? 'w' : 'ok'} sm onClick={() => toggleActivo(m)}>{m.activo ? 'Desactivar' : 'Activar'}</Btn>
            <Btn variant="d" sm onClick={() => eliminar(m.id)}>Eliminar</Btn>
          </div>
        </div>
      ))}
      {showForm && <StaffModal editing={editing} onGuardar={guardar} onClose={() => { setShowForm(false); setEditing(null) }} />}
    </div>
  )
}

function StaffModal({ editing, onGuardar, onClose }) {
  const [form, setForm] = useState({ nombre: editing?.nombre || '', rol: editing?.rol || '', contacto: editing?.contacto || '', alias: editing?.alias || '', notas: editing?.notas || '' })
  const [saving, setSaving] = useState(false)
  const set = k => v => setForm(p => ({ ...p, [k]: v }))

  return (
    <div className="modal-bg" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div className="modal-title">{editing ? 'Editar miembro' : 'Nuevo miembro'}</div>
        <Fi label="Nombre *" value={form.nombre} onChange={set('nombre')} placeholder="Nombre completo" />
        <div className="g2">
          <Fi label="Rol" value={form.rol} onChange={set('rol')} placeholder="Operador, Host, Técnico..." />
          <Fi label="Contacto" value={form.contacto} onChange={set('contacto')} placeholder="7000-0000" />
        </div>
        <Fi label="Alias / Redes" value={form.alias} onChange={set('alias')} placeholder="@capecito" />
        <Fi label="Notas" as="textarea" value={form.notas} onChange={set('notas')} placeholder="Disponibilidad, especialidad..." />
        <div className="row">
          <Btn disabled={saving || !form.nombre.trim()} onClick={async () => { setSaving(true); await onGuardar(form); setSaving(false) }}>
            {saving ? 'Guardando...' : editing ? 'Actualizar' : 'Agregar'}
          </Btn>
          <Btn variant="s" onClick={onClose}>Cancelar</Btn>
        </div>
      </div>
    </div>
  )
}
